import seaborn as sns
import matplotlib.pyplot as plt

data = [
    [30, 32, 35, 33],
    [31, 34, 36, 35],
    [29, 31, 33, 32]
]

sns.heatmap(data, annot=True, cmap="coolwarm")

plt.title("Temperature Heatmap")
plt.xlabel("Time of Day")
plt.ylabel("Days")

plt.show()
