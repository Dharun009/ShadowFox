import seaborn as sns
import matplotlib.pyplot as plt

data = [
    [1, 2, 3],
    [2, 3, 4],
    [10, 11, 12]
]

sns.clustermap(data)

plt.show()
