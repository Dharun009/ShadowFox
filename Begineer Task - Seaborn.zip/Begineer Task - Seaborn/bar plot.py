import seaborn as sns
import matplotlib.pyplot as plt
category = ['A', 'B', 'C', 'D']
values = [10, 20, 15, 25]

sns.barplot(x=category, y=values)

plt.show()
