import seaborn as sns
import matplotlib.pyplot as plt

data = ['A', 'B', 'A', 'C', 'B', 'A']

sns.countplot(x=data)

plt.show()
