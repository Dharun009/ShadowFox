import seaborn as sns
import matplotlib.pyplot as plt

x = [1, 2, 3, 4, 5]
y = [5, 15, 25, 35, 45]

sns.lineplot(x=x, y=y)

plt.show()
