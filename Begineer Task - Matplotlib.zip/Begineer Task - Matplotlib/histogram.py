import matplotlib.pyplot as plt

marks = [45, 50, 52, 60, 65, 70, 72, 75, 80, 85, 90]

plt.hist(marks, bins=5,edgecolor='black')

plt.title("Student Marks")
plt.xlabel("Marks")
plt.ylabel("Number of Students")

plt.show()
