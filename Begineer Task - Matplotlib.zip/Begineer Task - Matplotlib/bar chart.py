import matplotlib.pyplot as plt
import numpy as np

cars= ['Toyota', 'Hyundai', 'Honda', 'Tata','Mahindra','BYD']
sales= [400, 350, 300,430, 450, 100]

plt.bar(cars, sales)
plt.title('Car sales')
plt.xlabel('cars brand')
plt.ylabel('Sales(in units)')
plt.show()
