import matplotlib.pyplot as plt

subjects = ['Math', 'Science', 'English', 'Sports']
hours = [4, 3, 2, 1]

plt.pie(hours, labels=subjects, autopct='%1.1f%%')

plt.title("Daily Study Time Distribution")

plt.show()
