import matplotlib.pyplot as plt
import numpy as np
hours = np.array([1, 2, 3, 4, 5])
marks = np.array([30, 40, 50, 65, 75])
plt.scatter(hours, marks)
m, b = np.polyfit(hours, marks, 1)
plt.plot(hours, m*hours + b)
plt.title("Study Hours vs Marks")
plt.xlabel("Study Hours")
plt.ylabel("Marks")
plt.show()
